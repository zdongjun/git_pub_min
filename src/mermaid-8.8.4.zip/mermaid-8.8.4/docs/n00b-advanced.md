# Advanced n00b mermaid (Coming soon..)

## splitting mermaid code from html
A more condensed html code can be achieved by embedding the mermaid code in its own .js file, which is referenced like so:

```
stuff stuff
  </div>
  </body>
</html>
```
The actual mermaid file could for example look like this:

```
mermaid content...
```
---

## mermaid configuration options

...
