module.exports = intersectNode;

function intersectNode(node, point) {
  // console.info('Intersect Node');
  return node.intersect(point);
}
