const getStyles = () => ``;

export default getStyles;
